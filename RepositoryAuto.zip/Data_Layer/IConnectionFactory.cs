﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Data_Layer
{
    public interface IConnectionFactory
    {
        IDbConnection Create();

        void AddFactory(string connectionName);
    }
}
