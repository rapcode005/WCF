﻿using DomainModel;
using Data_Layer.Extensions;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using AutoMapper;

namespace Data_Layer
{
    public class PersonRepository : Repository<Person>, IPersonRepository
    {
        private DbContext _context;

        public PersonRepository(DbContext context) : base(context)
        {
            _context = context;
        }

        public virtual IList<Person> SearchPerson(string search, string searchType)
        {
            using (var command = _context.CreateCommand())
            {
                command.CommandType = CommandType.StoredProcedure;
                command.CommandText = "SearchPerson";

                command.Parameters.Add(command.CreateParameter("@sqlSearch", search));
                command.Parameters.Add(command.CreateParameter("@sqlSearchType", searchType));

                return this.ToList(command).ToList();
            }
        }
        public virtual IList<Person> SortPerson(bool IsAsc, string orderBy, string search, string searchType)
        {
            using (var command = _context.CreateCommand())
            {
                command.CommandType = CommandType.StoredProcedure;
                command.CommandText = "SortPerson";

                command.Parameters.Add(command.CreateParameter("@sqlIsAsc", IsAsc));
                command.Parameters.Add(command.CreateParameter("@sqlOrderBy", orderBy));
                command.Parameters.Add(command.CreateParameter("@sqlSearch", search));
                command.Parameters.Add(command.CreateParameter("@sqlSearchType", searchType));

                return this.ToList(command).ToList();
            }
        }
        public virtual Person AddNewPerson(Person newperson)
        {
            using (var command = _context.CreateCommand())
            {
                command.CommandType = CommandType.StoredProcedure;
                command.CommandText = "AddPerson";

                command.Parameters.Add(command.CreateParameter("@sqlAge", newperson.Age));
                command.Parameters.Add(command.CreateParameter("@sqlFirstName", newperson.FirstName));
                command.Parameters.Add(command.CreateParameter("@sqlLastName",
                newperson.LastName));

                return this.ToList(command).FirstOrDefault();
            }
        }
        public virtual Person UpdatePerson(Person newperson)
        {
            using (var command = _context.CreateCommand())
            {
                command.CommandType = CommandType.StoredProcedure;
                command.CommandText = "UpdatePerson";

                command.Parameters.Add(command.CreateParameter("@sqlID", newperson.Id));
                command.Parameters.Add(command.CreateParameter("@sqlAge", newperson.Age));
                command.Parameters.Add(command.CreateParameter("@sqlFirstName", newperson.FirstName));
                command.Parameters.Add(command.CreateParameter("@sqlLastName",
                newperson.LastName));
                command.Parameters.Add(command.CreateParameter("@sqlData", newperson.Data));

                return this.ToList(command).FirstOrDefault();
            }
        }

        public virtual Person DeletePerson(int id)
        {
            using (var command = _context.CreateCommand())
            {
                command.CommandType = CommandType.StoredProcedure;
                command.CommandText = "DeletePerson";

                command.Parameters.Add(command.CreateParameter("@sqlID", id));

                return this.ToList(command).FirstOrDefault();
            }
        }
        public virtual IList<Person> GetAllPerson()
        {
            using (var command = _context.CreateCommand())
            {
                command.CommandText = "exec [dbo].[GetAllPerson]";

                return this.ToList(command).ToList();
            }
        }

    }
}
