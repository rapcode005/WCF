﻿using DomainModel;
using System.Collections.Generic;

namespace Data_Layer
{
    public interface IPersonRepository
    {
        Person AddNewPerson(Person newperson);
        Person DeletePerson(int id);
        IList<Person> GetAllPerson();
        IList<Person> SearchPerson(string search, string searchType);
        IList<Person> SortPerson(bool IsAsc, string orderBy, string search, string searchType);
        Person UpdatePerson(Person newperson);
    }
}