﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.Text;
using System.Threading.Tasks;

namespace DomainModel
{
    [DataContract]
    public class PersonDto
    {
        [DataMember]
        public int Id { get; set; }
        [DataMember]
        public int Age { get; set; }
        [DataMember]
        public string FirstName { get; set; }
        [DataMember]
        public string LastName { get; set; }
        [DataMember]
        public string Data { get; set; }

        /*
        private int _id;
        private string _firstName;
        private string _lastName;
        private int _age;
        private string _data;

        [DataMember]
        public int Id 
        { 
            get => _id;
            set
            {
                _id = value;
                OnPropertyChanged("Id");
            }
        }
        [DataMember]
        public int Age 
        {
            get => _age;
            set
            {
                _age = value;
                OnPropertyChanged("Age");
            }
        }
        [DataMember]
        public string FirstName 
        {
            get => _firstName;
            set
            {
                _firstName = value;
                OnPropertyChanged("FirstName");
            }
        }
        [DataMember]
        public string LastName 
        {
            get => _lastName;
            set
            {
                _lastName = value;
                OnPropertyChanged("LastName");
            }
        }
        [DataMember]
        public string Data 
        {
            get => _data; 
            set
            {
                _data = value;
                OnPropertyChanged("Data");
            }
        }*/
    }
}
