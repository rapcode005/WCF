﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using DomainModel;
using AutoMapper;

namespace DomainModel
{
    public static class MapExtension
    {
        public static PersonDto ConvertToDTO(this Person dt)
        {
            var config = new MapperConfiguration(cfg =>
            cfg.CreateMap<Person, PersonDto>());

            return new Mapper(config).Map<PersonDto>(dt);
        }

        public static IList<PersonDto> ConvertListToDTO(this IList<Person> dt)
        {
            var config = new MapperConfiguration(cfg =>
            cfg.CreateMap<Person, PersonDto>());

            return new Mapper(config).Map<IList<PersonDto>>(dt);
        }

        public static Person ConvertToNonDTO(this PersonDto dt)
        {
            var config = new MapperConfiguration(cfg =>
            cfg.CreateMap<PersonDto, Person>());

            return new Mapper(config).Map<Person>(dt);
        }
    }
}
