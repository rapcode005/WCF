﻿using DomainModel;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.ServiceModel;
using System.ServiceModel.Web;
using System.Text;

namespace WCFPerson
{
    // NOTE: You can use the "Rename" command on the "Refactor" menu to change the interface name "IPersonService" in both code and config file together.
    [ServiceContract]
    public interface IPersonService
    {
        // TODO: Add your service operations here
        [OperationContract]
        IList<PersonDto> GetPersonData();
        [OperationContract]
        PersonDto AddPersonData(PersonDto NewPerson);
        [OperationContract]
        PersonDto UpdatePersonData(PersonDto NewPerson);
        [OperationContract]
        PersonDto DeletePersonData(int id);
        [OperationContract]
        IList<PersonDto> SearchPersonData(string search, string searchType);
        [OperationContract]
        IList<PersonDto> SortPersonData(bool IsAsc, string orderBy, string search, string searchType);
    }

    /*
    // Use a data contract as illustrated in the sample below to add composite types to service operations.
    [DataContract]
    public class CompositeType
    {
        bool boolValue = true;
        string stringValue = "Hello ";

        [DataMember]
        public bool BoolValue
        {
            get { return boolValue; }
            set { boolValue = value; }
        }

        [DataMember]
        public string StringValue
        {
            get { return stringValue; }
            set { stringValue = value; }
        }
    }*/
}

xUnit
UnitTest
mock(Purpose of unit testing-  component)