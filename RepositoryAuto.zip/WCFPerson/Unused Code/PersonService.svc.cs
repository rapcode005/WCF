﻿using DomainModel;
using RepositoryAuto;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.ServiceModel;
using System.ServiceModel.Description;
using System.ServiceModel.Web;
using System.Text;

namespace WCFPerson
{

    // NOTE: You can use the "Rename" command on the "Refactor" menu to change the class name "PersonService" in code, svc and config file together.
    // NOTE: In order to launch WCF Test Client for testing this service, please select PersonService.svc or PersonService.svc.cs at the Solution Explorer and start debugging.
    public class PersonService : IPersonService
    {
        private IConnectionFactory connectionFactory;

        public PersonDto AddPersonData(PersonDto NewPerson)
        {
            connectionFactory = ConnectionHelper.GetConnection();

            var context = new DbContext(connectionFactory);

            var personRep = new PersonRepository(context);

            return personRep.AddNewPerson(NewPerson);
        }

        public PersonDto DeletePersonData(int id)
        {
            connectionFactory = ConnectionHelper.GetConnection();

            var context = new DbContext(connectionFactory);

            var personRep = new PersonRepository(context);

            return personRep.DeletePerson(id);
        }

        public IList<PersonDto> GetPersonData()
        {           
            connectionFactory = ConnectionHelper.GetConnection();

            var context = new DbContext(connectionFactory);

            var personRep = new PersonRepository(context);

            return personRep.GetAllPerson();
        }

        public IList<PersonDto> SearchPersonData(string search, string searchType)
        {
            connectionFactory = ConnectionHelper.GetConnection();

            var context = new DbContext(connectionFactory);

            var personRep = new PersonRepository(context);

            return personRep.SearchPerson(search, searchType);
        }

        public IList<PersonDto> SortPersonData(bool IsAsc, string orderBy, string search, string searchType)
        {
            connectionFactory = ConnectionHelper.GetConnection();

            var context = new DbContext(connectionFactory);

            var personRep = new PersonRepository(context);

            return personRep.SortPerson(IsAsc, orderBy, search, searchType);
        }

        public PersonDto UpdatePersonData(PersonDto NewPerson)
        {
            connectionFactory = ConnectionHelper.GetConnection();

            var context = new DbContext(connectionFactory);

            var personRep = new PersonRepository(context);

            return personRep.UpdatePerson(NewPerson);
        }
    }
}
