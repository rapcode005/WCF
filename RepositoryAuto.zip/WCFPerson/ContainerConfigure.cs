﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using Autofac;
using Data_Layer;
using Services;

namespace WCFPerson
{
    public static class ContainerConfigure
    {
        public static IContainer Build()
        {
            var builder = new ContainerBuilder();
            builder.RegisterType<PersonRepository>().As<IPersonRepository>();
            builder.RegisterGeneric(typeof(Repository<>)).As(typeof(Repository<>));
            builder.RegisterType<AdoNetUnitOfWork>().As<IUnitOfWork>();
            builder.RegisterType<DbConnectionFactory>().As<IConnectionFactory>();
            builder.RegisterType<PersonServices>().As<IPersonServices>();

            return builder.Build();
        }
    }
}