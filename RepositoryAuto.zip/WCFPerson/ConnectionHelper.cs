﻿using Data_Layer;

namespace WCFPerson
{
    public class ConnectionHelper
    {
        public static IConnectionFactory GetConnection()
        {
            return new DbConnectionFactory("Person");
        }
    }
}