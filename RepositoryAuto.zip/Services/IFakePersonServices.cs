﻿using DomainModel;
using System.Collections.Generic;

namespace Services
{
    public interface IFakePersonServices
    {
        PersonDto AddPersonData(PersonDto NewPerson);
        PersonDto DeletePersonData(int id);
        IList<PersonDto> GetPersonData();
        IList<PersonDto> SearchPersonData(string search, string searchType);
        IList<PersonDto> SortPersonData(bool IsAsc, string orderBy, string search, string searchType);
        PersonDto UpdatePersonData(PersonDto NewPerson);
    }
}