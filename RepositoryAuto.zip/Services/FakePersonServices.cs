﻿using Data_Layer;
using DomainModel;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Services
{
    public class FakePersonServices : IFakePersonServices
    {

        private IConnectionFactory connectionFactory;
        private DbContext context;
        private PersonRepository personRep;

        public FakePersonServices(DbContext _context,
            PersonRepository repository,
            IConnectionFactory conn)
        {
            personRep = repository;
            context = _context;
            connectionFactory = conn;
        }

        public PersonDto AddPersonData(PersonDto NewPerson)
        {
            //connectionFactory = ConnectionHelper.GetConnection();

            //context = new DbContext(connectionFactory);

            //personRep = new PersonRepository(context);

            Person p = NewPerson.ConvertToNonDTO();

            return personRep.AddNewPerson(p)
                .ConvertToDTO();
        }

        public PersonDto DeletePersonData(int id)
        {
            //connectionFactory = ConnectionHelper.GetConnection();

            //context = new DbContext(connectionFactory);

            //personRep = new PersonRepository(context);

            return personRep.DeletePerson(id).ConvertToDTO();
        }

        public IList<PersonDto> GetPersonData()
        {
           //connectionFactory = ConnectionHelper.GetConnection();

           /// context = new DbContext(connectionFactory);

            //personRep = new PersonRepository(context);

            return personRep.GetAllPerson().ConvertListToDTO();
        }

        public IList<PersonDto> SearchPersonData(string search, string searchType)
        {
            //connectionFactory = ConnectionHelper.GetConnection();

            //context = new DbContext(connectionFactory);

            //personRep = new PersonRepository(context);

            return personRep.SearchPerson(search, searchType).ConvertListToDTO();
        }

        public IList<PersonDto> SortPersonData(bool IsAsc, string orderBy, string search, string searchType)
        {
            //connectionFactory = ConnectionHelper.GetConnection();

            //context = new DbContext(connectionFactory);

            //personRep = new PersonRepository(context);

            return personRep.SortPerson(IsAsc, orderBy,
                search, searchType).ConvertListToDTO();
        }

        public PersonDto UpdatePersonData(PersonDto NewPerson)
        {
            //connectionFactory = ConnectionHelper.GetConnection();

            //context = new DbContext(connectionFactory);

            //personRep = new PersonRepository(context);

            Person p = NewPerson.ConvertToNonDTO();

            return personRep.UpdatePerson(p).ConvertToDTO();
        }
    }
}
