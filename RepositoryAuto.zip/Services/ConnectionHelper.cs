﻿using Data_Layer;

namespace Services
{
    public class ConnectionHelper
    {
        public static IConnectionFactory GetConnection()
        {
            return new DbConnectionFactory("Person");
        }
    }
}