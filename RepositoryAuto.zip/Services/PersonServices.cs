﻿using Data_Layer;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using DomainModel;

namespace Services
{
    public class PersonServices : IPersonServices
    {
        public PersonDto AddPersonData(PersonDto NewPerson)
        {
            var connectionFactory = ConnectionHelper.GetConnection();

            var context = new DbContext(connectionFactory);

            var personRep = new PersonRepository(context);

            Person p = NewPerson.ConvertToNonDTO();

            return personRep.AddNewPerson(p)
                .ConvertToDTO();
        }

        public PersonDto DeletePersonData(int id)
        {
            var connectionFactory = ConnectionHelper.GetConnection();

            var context = new DbContext(connectionFactory);

            var personRep = new PersonRepository(context);

            return personRep.DeletePerson(id).ConvertToDTO();
        }

        public IList<PersonDto> GetPersonData()
        {
            var connectionFactory = ConnectionHelper.GetConnection();

            var context = new DbContext(connectionFactory);

            var personRep = new PersonRepository(context);

            return personRep.GetAllPerson().ConvertListToDTO();
        }

        public IList<PersonDto> SearchPersonData(string search, string searchType)
        {
            var connectionFactory  = ConnectionHelper.GetConnection();

            var context = new DbContext(connectionFactory);

            var personRep = new PersonRepository(context);

            return personRep.SearchPerson(search, searchType).ConvertListToDTO();
        }

        public IList<PersonDto> SortPersonData(bool IsAsc, string orderBy, string search, string searchType)
        {
            var connectionFactory  = ConnectionHelper.GetConnection();

            var context = new DbContext(connectionFactory);

            var personRep = new PersonRepository(context);

            return personRep.SortPerson(IsAsc, orderBy, 
                search, searchType).ConvertListToDTO();
        }

        public PersonDto UpdatePersonData(PersonDto NewPerson)
        {
            var connectionFactory  = ConnectionHelper.GetConnection();

            var context = new DbContext(connectionFactory);

            var personRep = new PersonRepository(context);

            Person p = NewPerson.ConvertToNonDTO();

            return personRep.UpdatePerson(p).ConvertToDTO();
        }
    }
}
