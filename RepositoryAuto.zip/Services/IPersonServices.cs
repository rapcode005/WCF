﻿using DomainModel;
using System.Collections.Generic;
using System.ServiceModel;

namespace Services
{
    [ServiceContract]
    public interface IPersonServices
    {
        [OperationContract]
        PersonDto AddPersonData(PersonDto NewPerson);
        [OperationContract]
        PersonDto DeletePersonData(int id);
        [OperationContract]
        IList<PersonDto> GetPersonData();
        [OperationContract]
        IList<PersonDto> SearchPersonData(string search, string searchType);
        [OperationContract]
        IList<PersonDto> SortPersonData(bool IsAsc, string orderBy, string search, string searchType);
        [OperationContract]
        PersonDto UpdatePersonData(PersonDto NewPerson);
    }
}